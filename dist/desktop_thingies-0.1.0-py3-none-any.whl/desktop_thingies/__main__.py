from desktop_thingies import main

main()
